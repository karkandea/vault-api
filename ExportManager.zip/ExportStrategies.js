﻿// wwwroot/js/export/ExportStrategies.js
(function ($) {

    window.ExportStrategies = window.ExportStrategies || {};

    // ============================================
    // FINANCE STRATEGY - Logic & params
    // ============================================
    window.ExportStrategies.Finance = (function ($) {

        function getParams() {
            const reqTypeVal = $('#search_request_type').val();
            const reqTypeText = reqTypeVal ? $('#search_request_type option:selected').text() : null;

            const requestorVal = $('#search_requestor_name').val();
            const requestorText = requestorVal ? $('#search_requestor_name option:selected').text() : null;

            const makerVal = $('#search_maker_finance').val();
            const makerText = makerVal ? $('#search_maker_finance option:selected').text() : null;

            const reportType = $('#report_type').val();
            const reportTypeText = reportType ? $('#report_type option:selected').text() : '';

            const isCashAdvance = reportTypeText?.includes("Cash Advance") ?? false;
            const isReportAudit = reportTypeText?.includes('Audit') ?? false;

            return {
                PaymentListRequest: {
                    // Bind parameter khusus Inquiry Payment report
                    requestType: reqTypeText === "ALL" ? null : reqTypeText,
                    requestNumber: $('#search_request_number').val() || null,
                    voucherNumber: $('#search_voucher_number').val() || null,
                    transferNumber: $('#search_transfer_number').val() || null,
                    vendorCategoryId: $('#search_vendor_category').val() || null,
                    vendorId: $('#search_vendor').val() || null,
                    accountMasterId: $('#search_account_master').val() || null,
                    businessUnitId: $('#search_business_unit').val() || null,
                    costCenterId: $('#search_cost_center').val() || null,
                    requestStatus: $('#search_request_status').val() || null,
                    statusTransfer: $('#search_payment_status').val() || null,
                    currency: $('#search_currency').val() || null,
                    requestorName: requestorText === "ALL" ? null : requestorText,
                    makerFinance: makerText === "ALL" ? null : makerText,
                    requestDateFrom: $('#search_start_date').val() || null,
                    requestDateTo: $('#search_end_date').val() || null,
                    paymentDateFrom: $('#search_payment_start_date').val() || null,
                    paymentDateTo: $('#search_payment_end_date').val() || null,
                    isCashAdvance: isCashAdvance,
                    reportType: reportType || null,
                    isReportAudit: isReportAudit
                },
                ReportTypeCategory: "InquiryPayment"
            };
        }

        function getConfig(globalConfig) {
            return {
                baseUrl: globalConfig.baseUrl,
                baseUrlAPS: globalConfig.baseUrlAPS, 
                endpoints: {
                    request: '/Report/RequestExport',
                    status: '/Report/GetStatus?jobsId={jobId}',
                    download: '/Report/download?jobId={jobId}'
                },
                polling: {
                    intervalMs: 3000,
                    maxAttempts: 60,
                    showProgress: true
                },
                getParams: getParams
            };
        }

        function create(globalConfig) {
            return window.ExportManager.create(getConfig(globalConfig));
        }

        return {
            create: create,
            getConfig: getConfig,
            getParams: getParams
        };

    })(jQuery);


    // ============================================
    // PO STRATEGY - Contoh untuk Purchase Order
    // ============================================
    window.ExportStrategies.Po = (function ($) {

        function getParams() {
            return {
                // Bind parameter khusus Purchase order report
                PurchaseOrderRequest: {
                    x: 1,
                    PR_Category_Id: $('select#PR_Category_Id :selected').val()?.trim() ?? '',
                    PR_Category_Text: $('select#PR_Category_Id :selected').text(),
                    PR_No: $('input#PR_No').val()?.trim() ?? '',
                    PR_Status_ValueId: $('select#PR_Status_ValueId :selected').val()?.trim() ?? '',
                    PR_Status_Text: $('select#PR_Status_ValueId :selected').text(),
                    PR_Date_Begin: $('input#PR_Date_Begin').val()?.trim() ?? '',
                    PR_Date_End: $('input#PR_Date_End').val()?.trim() ?? '',
                    Department_Id: $('select#Department_Id :selected').val()?.trim() ?? '',
                    Department_Text: $('select#Department_Id :selected').text(),
                    Account_Code_Id: $('select#Account_Code_Id :selected').val()?.trim() ?? '',
                    Account_Code_Text: $('select#Account_Code_Id :selected').text(),
                    Cost_Center_Id: $('select#Cost_Center_Id :selected').val()?.trim() ?? '',
                    Cost_Center_Text: $('select#Cost_Center_Id :selected').text(),
                    Vendor_Id: $('select#Vendor_Id :selected').val()?.trim() ?? '',
                    Vendor_Text: $('select#Vendor_Id :selected').text(),
                    Order_Type_Id: $('select#Order_Type_Id :selected').val()?.trim() ?? '',
                    Order_Type_Text: $('select#Order_Type_Id :selected').text(),
                    Order_No: $('input#Order_No').val()?.trim() ?? '',
                    Order_Status_Text: $('select#Order_Status_ValueId :selected').text(),
                    Order_Status_ValueId: $('select#Order_Status_ValueId :selected').val()?.trim() ?? '',
                    Order_Date_Begin: $('input#Order_Date_Begin').val()?.trim() ?? '',
                    Order_Date_End: $('input#Order_Date_End').val()?.trim() ?? ''
                },
                ReportTypeCategory: "PurchaseOrder"

            };
        }

        function getConfig(globalConfig) {
            return {
                baseUrl: globalConfig.baseUrl,
                baseUrlAPS: globalConfig.baseUrlAPS,
                endpoints: {
                    request: '/Report/RequestExport',
                    status: '/Report/GetStatus?jobsId={jobId}',
                    download: '/Report/download?jobId={jobId}'
                },
                polling: {
                    intervalMs: 3000,
                    maxAttempts: 60,
                    showProgress: true
                },
                getParams: getParams
            };
        }

        function create(globalConfig) {
            return window.ExportManager.create(getConfig(globalConfig));
        }

        return {
            create: create,
            getConfig: getConfig,
            getParams: getParams
        };

    })(jQuery);

})(jQuery);