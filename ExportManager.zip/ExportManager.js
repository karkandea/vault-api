﻿window.ExportManager = (function ($) {

    function ExportManager(config) {
        this.config = $.extend(true, {}, config);
        this.progressBar = '';
    }

    ExportManager.prototype.ajaxFetch = function (endpoint, options) {
        var self = this;
        options = options || {};

        return new Promise(function (resolve) {
            var url = endpoint;

            if (options.jobId && url.indexOf('{jobId}') !== -1) {
                url = url.replace('{jobId}', options.jobId);
            } else if (url.indexOf('http') !== 0) {
                url = self.config.baseUrl + url;
            }

            console.debug('📡 AJAX ' + (options.type || 'GET') + ' → ' + url);

            $.ajax({
                url: url,
                type: options.type || 'GET',
                contentType: 'application/json',
                data: JSON.stringify(options.data),
                processData: false,
                timeout: 30000,
                headers: options.headers || {},
                success: function (response, textStatus, xhr) {
                    resolve({
                        ok: xhr.status >= 200 && xhr.status < 300,
                        status: xhr.status,
                        response: response,
                        xhr: xhr
                    });
                },
                error: function (xhr, textStatus, errorThrown) {
                    var errorData = null;
                    if (xhr.responseJSON) {
                        errorData = xhr.responseJSON;
                    } else if (xhr.responseText) {
                        try {
                            errorData = JSON.parse(xhr.responseText);
                        } catch (e) {
                            errorData = { error: xhr.responseText || errorThrown };
                        }
                    }
                    resolve({
                        ok: false,
                        status: xhr.status,
                        error: errorData || { message: errorThrown || textStatus },
                        xhr: xhr
                    });
                }
            });
        });
    };

    ExportManager.prototype.requestExport = function (customParams) {
        var self = this;
        customParams = customParams || {};

        var baseParams = (typeof this.config.getParams === 'function')
            ? this.config.getParams()
            : {};

        var payload = $.extend(true, {}, baseParams, customParams);

        return this.ajaxFetch(this.config.endpoints.request, {
            type: 'POST',
            data: payload
        }).then(function (result) {
            console.log('🔍 requestExport response:', result);

            if (result.ok && result.response) {
                var resp = result.response;

                var jobId = resp.jobId                    // camelCase (sesuai response Anda)
                    || resp.JobId                    // PascalCase
                    || (resp.Data && resp.Data.jobId)  // nested camelCase
                    || (resp.Data && resp.Data.JobId); // nested PascalCase

                if (jobId) {
                    console.log('✅ Job created:', jobId);

                    if (window.ExportToast) {
                        window.ExportToast.fire({
                            icon: 'info',
                            title: '📤 Export in progress...',
                            text: 'Running in background. You can continue working.'
                        });
                    }
                    return jobId;
                }
            }

            // ❌ Jika tidak ada jobId
            var errorMsg = (result.error && result.error.message)
                ? result.error.message
                : (result.response && (result.response.errorMessage || result.response.ErrorMessage))
                    ? (result.response.errorMessage || result.response.ErrorMessage)
                    : 'Please check filters and try again';

            console.warn('Failed to get jobId from response:', result.response);

            if (window.ExportToast) {
                window.ExportToast.fire({
                    icon: 'error',
                    title: '❌ Export failed to start',
                    text: errorMsg,
                    timer: 3000
                });
            }
            return null;
        });
    };

    ExportManager.prototype.checkStatus = function (jobId, silent) {
        var self = this;
        silent = silent || false;

        if (!jobId) {
            if (!silent) console.error('❌ jobId required for status check');
            return Promise.resolve(null);
        }

        var endpoint = this.config.endpoints.status.replace('{jobId}', jobId);
        var url = this.config.baseUrl + endpoint;

        if (!silent) {
            console.debug('🔍 [checkStatus] Full URL:', url);
        }

        return this.ajaxFetch(endpoint, { type: 'GET' }).then(function (result) {
            if (result.ok && result.response) {
                var data = result.response.Data || result.response;

                var status = data.Status || data.status;
                var errorMessage = data.ErrorMessage || data.errorMessage;

                if (!silent && self.config.polling && self.config.polling.showProgress) {
                    var shortId = jobId.length > 8 ? jobId.slice(0, 8) + '...' : jobId;
                    console.debug('📊 Status[' + shortId + ']: ' + status);
                }

                return {
                    Status: status,
                    ErrorMessage: errorMessage,
                    JobId: data.JobId || data.jobId || jobId,
                    CreatedAt: data.CreatedAt || data.createdAt
                };
            }
            return null;
        });
    };

    ExportManager.prototype.pollStatus = function (jobId, onProgress) {
        var self = this;
        var pollingConfig = this.config.polling || {};
        var intervalMs = pollingConfig.intervalMs || 3000;
        var maxAttempts = pollingConfig.maxAttempts || 60;
        var showProgress = pollingConfig.showProgress !== false;
        var attempt = 0;
        var progressBar = '';

        function pollLoop() {
            return self.checkStatus(jobId, true).then(function (status) {
                attempt++;

                if (!status) {
                    if (attempt < maxAttempts) {
                        return self.sleep(intervalMs).then(pollLoop);
                    }
                    return null;
                }

                // Progress callback
                if (showProgress && typeof onProgress === 'function') {
                    var progress = Math.round((attempt / maxAttempts) * 100);
                    var filled = Math.floor(progress / 5);
                    progressBar = '█'.repeat(filled) + '░'.repeat(20 - filled);
                    onProgress({
                        attempt: attempt,
                        maxAttempts: maxAttempts,
                        progress: progress,
                        status: status.Status || status.status,
                        progressBar: progressBar
                    });
                }

                // Terminal states
                if (status.Status === 'Completed' || status.Status === 'Failed') {
                    return status;
                }

                // Continue polling
                if (attempt < maxAttempts) {
                    return self.sleep(intervalMs).then(pollLoop);
                }

                // Timeout reached - final check
                return self.checkStatus(jobId, false);
            });
        }

        return pollLoop();
    };

    ExportManager.prototype.downloadFile = function (jobId) {
        if (!jobId) {
            console.error('❌ jobId required for download');
            return Promise.resolve(false);
        }

        var baseUrl = this.config.baseUrlAPS;
        var url = baseUrl + `/${jobId}/download`;

        console.log('🔗 Download URL:', url);

        if (window.ExportToast) {
            window.ExportToast.fire({
                icon: 'success',
                title: '⬇️ Downloading...',
                timer: 2000
            });
        }

        window.open(url, '_blank');
        return Promise.resolve(true);
    };

    ExportManager.prototype.sleep = function (ms) {
        return new Promise(function (resolve) {
            setTimeout(resolve, ms);
        });
    };

    ExportManager.prototype.exportAndDownload = function (overrideParams, callbacks) {
        var self = this;
        overrideParams = overrideParams || {};
        callbacks = callbacks || {};

        var pollInterval = (this.config.polling && this.config.polling.intervalMs) ? this.config.polling.intervalMs : 3000;
        var progressToastShown = false;

        console.log(' Export started at: ' + new Date().toLocaleTimeString());

        return this.requestExport(overrideParams).then(function (jobId) {
            if (!jobId) {
                console.error('Flow stopped: Failed to create export job');
                if (typeof callbacks.onError === 'function') {
                    callbacks.onError('Failed to create export job');
                }
                if (window.Swal) {
                    window.Swal.fire('Failed!', 'Failed to create export job. Check console for details.', 'error');
                }
                return { success: false, jobId: null };
            }

            // Step 2: Polling with inner function
            function poll() {
                return self.checkStatus(jobId, false).then(function (statusResult) {
                    if (!statusResult) {
                        console.warn('Could not fetch status, retrying...');
                        setTimeout(poll, pollInterval);
                        return;
                    }

                    var currentStatus = statusResult.Status || statusResult.status;
                    var errorMessage = statusResult.ErrorMessage || statusResult.errorMessage;

                    // Progress feedback (first time only)
                    if (!progressToastShown) {
                        progressToastShown = true;
                        console.log('Status: ' + currentStatus);

                        if (window.ExportToast) {
                            window.ExportToast.fire({
                                icon: 'info',
                                title: '⏳ Generating your file...',
                                text: 'Please wait, this may take a moment',
                                timer: 3000
                            });
                        }

                        if (typeof callbacks.onProgress === 'function') {
                            callbacks.onProgress({ status: currentStatus });
                        }
                    }

                    // COMPLETED
                    if (currentStatus === 'Completed') {
                        if (window.ExportToast) {
                            window.ExportToast.fire({
                                icon: 'success',
                                title: '✅ Export complete!',
                                showConfirmButton: true,
                                confirmButtonText: '⬇️ Download',
                                timer: 10000
                            }).then(function (result) {
                                if (result.isConfirmed) {
                                    self.downloadFile(jobId);
                                }
                            });
                        }

                        // Auto-download fallback after 3 seconds
                        setTimeout(function () {
                            self.downloadFile(jobId);
                        }, 3000);

                        console.log('🎉 Export completed');
                        if (typeof callbacks.onComplete === 'function') {
                            callbacks.onComplete({ jobId: jobId, status: statusResult });
                        }
                        return { success: true, jobId: jobId, status: statusResult };
                    }

                    // ✅ FAILED
                    if (currentStatus === 'Failed') {
                        if (window.ExportToast) {
                            window.ExportToast.fire({
                                icon: 'error',
                                title: '❌ Export failed',
                                text: errorMessage || 'Unknown error',
                                timer: 5000
                            });
                        }
                        console.error('💥 Export failed:', errorMessage);
                        if (typeof callbacks.onError === 'function') {
                            callbacks.onError(errorMessage || 'Export failed');
                        }
                        return { success: false, jobId: jobId, error: errorMessage };
                    }

                    console.log('Still ' + currentStatus + '... retry in ' + (pollInterval / 1000) + 's');
                    setTimeout(poll, pollInterval);
                });
            }

            setTimeout(poll, pollInterval);
            return { success: true, jobId: jobId };
        });
    };

    ExportManager.create = function (config) {
        return new ExportManager(config);
    };

    return ExportManager;

})(jQuery);